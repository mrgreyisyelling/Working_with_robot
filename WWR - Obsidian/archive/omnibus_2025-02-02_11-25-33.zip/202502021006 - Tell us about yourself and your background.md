I am a sociologist who specialized in social network analysis. I dropped out to become a landlord - so I am ABD. I ran a stable business until covid and then I tried running a 'humanitarian' business, and got eaten alive. 

I believe that organizing knowledge locally is important. I have studied favelas, personal relationships and the cliquish nature of Notre Dame - I have had a variety of experiences dealing with knowledge, and my motivation is the preservation of unique knowledge. 

Mapping understanding means very clearly defining the channel and community you are speaking into. Reddit level. r/lansing_jobseekers , r/lansing_education.

Its because meanings drift over time - so the systems that capture them need to easily be able to define them.

Community
- manner of talking about Jobs
- manner of talking about education
etc

then you have the ability to compare communities of thought. This difference making helps the groups relate to one another, by acknowledging differences and difficulties.

How do you define a community though? objectively and subjective - both are wrong. This is because community and social organization arises from the behavior of the group. Abstractly the idea may exist, but until that abstraction is confirmed in the behavior of others, its not clear if it things are mutually understood. 

Therefore - it is easier to define community in an 'opt in' manner, with extremely limited ports of entry. 

The goal is maximum membership - but that is complex. what is something that all groups can opt into that they all mutually share the same understanding or believe they do.

really abstract things, sure, but the more local it becomes - the more difficult it is to have complete membership about anything. Because - specifics in relations matter, and most description is used to contrast. If the point of reference is not known- you can't make these assumptions.

So - therefore, creating a narrow context in which narrow use can be created, is the best way to reinforce meaning.

The DDC from the EEU will do that. Why isn't the DDC and the EEU the same - because EEU will never be big enough to serve everyone, though membership is unlimited. Because the way to create mutual benefit is to focus on a very  narrow scope and push.  Therefore - many EEEus will need to exist. I think one every 150 people would make sense - approximately the size of a CCU. 36 babies, 6 teachers, 72 parents and one grandparent each. 

Every cluster of 150 people focused on this or that batch of babies, is the basic organizing unit of people. 

In this context - the diversity of the parents and others becomes limited to the choices the parents will make about the children. from that narrow context - conflict and connection will be established, for a short period of about 4 years

My goal is to use this 'education units' as a basis of analysis, to measure and describe local communities.

So in my project, I am going to develop the tool necessary to capture this context. It will be modifyable - but it will provide the necessary base interlinkages to help concentrate and organize infromatino.

Babies - by their nature - are the product of their network of relationsihps. While they may be connected to abstract entities, these concepts do not have the same meaning. so their relationship to the world is much more direct. And therefore limited.

What we are going to be using a base unit of the CCU to evaluate and organize knowledge -Each baby in the CCU will have a larger context around them. Being able to measure and express that over time, will provide a tremendous amount of information back to the central cluster.

So my goal is to develop a system to establish the base community concepts of things like job and education. How does a community describe these things? How can this conception be reproduced automatically?

How can these things be captured, and how can they be used to describe a community?

' 

Hello - we are developing a local economic unit. We are measuring the local employment and skills sets.

Please in the field below - describe your current employment situation(s) and any skills that seem relevant. 
'

This data is heaped and mined - it is reduced to a different state and the request  language changes. 

Employment - types of employment, amount, 
process reduces it to 6 choices, and gathers specifics on the 6 parts.
Its an iterative process - questions constantly adjusting. 
Every sample begins  to describe the relationship to certain words people have.

From this data set - you train the model on sets of words and ideas - to createa corrispondence between these generic structures and these micro expressions

But you keep the base data as the source of language, and the coorispondance changes with time. 









