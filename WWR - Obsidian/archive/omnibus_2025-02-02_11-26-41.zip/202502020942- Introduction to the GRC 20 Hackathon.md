https://www.youtube.com/watch?v=8P-FEjYGI0Y

## Introduction to the GRC 20 Hackathon

0:00

all right GM GM hi everyone how's it going the graph Discord how is it going

0:06

graph devs we are streaming on graph devs and we are in chat in the graph

0:13

Discord and welcome to another episode of the graph Builders office hours and we've got a amazing guest again so he's

0:20

coming through I think you were here what a month or month and a half ago for the GRC 20 spec and you're back for the

0:27

GRC 20 hackathon we've got your knees tall every one how you doing you knes hey Marcus it's good to be back it was a

0:33

lot of fun last time and uh I'm excited for this one yeah this is this is I feel

0:40

a good representation of how Tech at the bleeding edge of tech is

0:49

best produced where we have a new spec getting feedback getting awareness to it which was a few weeks ago and now we're

0:55

like hey let's go use it and let's go push it into the public let's go ahead and see what people can actually move

1:01

forward with now the more I'm not going to use the word finalize but I'll use the word it's more well-shaped so really

1:08

exciting times hi everyone in chat how's it going uh we're going to wait probably two maybe three more minutes for people

1:15

to filter in I'm looking at chat right here just so everyone knows and uh in the meantime Y how is your day going so

1:23

far and how is preparing for this gc20 hackathon going yeah things are going

1:29

great I'm super excited exced for it uh we just announced it on Monday and with

1:34

basically one week for people to sign up so it's moving quickly but I'm glad that you know we do these uh you know Builder

1:41

office hours every week so had a chance to kind of jump on but yeah we're getting things ready we're ready to kick

1:46

things off it's coming right up yeah it is really coming right up I'm dropping the links in the chat excuse me they are

1:52

in Discord and they are going excuse me they're going to be on Twitter as well and so from there getting the word out

1:59

about this hack of and how's it going chat if there's any questions about this hackathons feel

2:04

free to Shir the questions there we'll be doing a Q&A at the end and in terms of announcements that we have going on

2:11

right now really the biggest announcement that I want to push is in fact this hackathon and for anyone out

2:16

there who is wanting to get into the Q&A in this this the Q&A that I'm looking at is in the graph Discord so go ahead and

2:23

jump into the graph Discord we do the graph Builder office hours every Thursday at 5:00 p.m. UTC and we feature

2:29

either core development teams within the graph ecosystem or we also feature Builders from the outside the ecosystem

## The Vision of Web3 and Knowledge Graphs

2:35

such as pains such as daps and we make sure that they get their shine because it's really important that developers of

2:42

all backgrounds all builds all come in here and share what they're building that's a really the Mind share is really a powerful setting scpt so any thoughts

2:49

that you want to share you need besides just getting right into the workshop happy to get started awesome awesome

2:56

okay so I'm going to step off stage I'll let you get started and chat like I said if there's any questions drop them in

3:01

and have a good presentation thank you I'm going to start sharing and let

3:09

me know if this does or doesn't work hopefully that's good so hey everyone it's great to be back with you and today

3:16

we're going to be talking about the GRC 20 hackathon uh that we announced on Monday it's going to be starting in just

3:23

a few days uh this upcoming Monday um so Post in the chat I can't actually

3:29

necessarily see right now but Post in the chat if you've been following the graph for at least two

3:35

years um lot's been happening over the last two years it's been a really fun time and post in the chat if you've been

3:43

following the graph for over four years so around the the network launch I'd be curious how many people

3:50

have been around since then um so for for those that have been using the graph and following the graph for a while you

3:57

know we've been working towards this vision of web 3 for a very long time really since

4:04

2017 and um and we're really excited we're going to be pushing this thing forward to the next stage you know it's

4:11

a really big Vision this whole web 3 idea and you know sometimes you have to take it just uh you know one step at a

4:18

time um so you know people that have been around for a while will remember that before we launched the graph

4:24

Network we did a hackathon called the Space Race um and uh there's going to be some commonality between this and the

4:30

Space Race we also did this kind of curator program but uh but you know this

4:35

is going to be a really big step in realizing the vision of web 3 um uh

4:42

people have been posting about the haathon on X which I really appreciate keep it up um I like this one from this

4:50

uh crypto commentator right this is the start of how we take all of the world's knowledge and bring it on chain

4:57

historic um so I agree I think is going to be historic um I want to start with

5:03

uh just a very quick overview uh of why knowledge graphs and and what is web 3

5:11

you know web 3 is in crypto is really a crazy industry right because we keep

5:16

cycling between these like Manas where we're like you know web 3 is going to change everything right it's this

5:23

revolution uh to to the other side where it's oh you know maybe it's not actually

5:28

going to be used for that much maybe it's just just you know bitcoin's a store of value and that's it or

5:34

something like that and the reality is I do think web 3 is going to change

## Organizing Knowledge for Web3 Applications

5:41

everything uh but we just needed the right pieces and um and and and I

5:48

believe we believe that knowledge graphs are really the missing piece right

5:53

because what is web 3 it's a new platform for decentralized applications

5:59

and specific speically it's a new web that's verifiable open and

6:04

composable right and you know with decentralized networks in crypto you know people kind of understand

6:10

verifiability and openness but what I think we've really been missing is this composability and knowledge graphs are

6:17

really the solution to composability right we want to create an a web where

6:23

the information is verifiable it's open and you can use it across applications

6:29

um and you know we start to see a little bit of that in some places in web 3 but you know to really unlock the real thing

6:36

we need like the right Primitives and uh GRC 20 is that primitive for composable

6:43

knowledge and information across applications um so uh we're going to

6:48

start uh hacking on that uh with this hackathon and this will be you know a

6:54

really great chance to learn a ton are you're going to learn about knowledge graphs learn about AI uh if you haven't

7:01

had a chance to play around with AI much uh and and especially if you have but in either way this will be a really great

7:08

way to you know brush up your chops learn from other people and help to bootstrap uh the next generation of web3

7:16

applications um so if you know we view web 3 as being right this open

7:22

verifiable composable web uh we want to bootstrap that we want to have organized

7:29

knowledge and information that people can use for their applications and you know this was really you know always a

7:35

big goal with the graph right is to have open data and open knowledge and information um that makes it easier for

7:42

people to build amazing applications um and uh uh you know for that you know the

7:48

high level goal is really just to have more useful knowledge and information better organized right the the the more

7:55

useful the knowledge is the the more applicable it is to a larger number of people the more people will benefit from

8:02

web 3 the more applications we can build on web 3 so that's really kind of this highlevel goal uh and as far as you know

8:10

developers you can really think of two different sides of this kind of web 3

8:15

organized graph equation right there's um organizing the knowledge that's kind of half of it right making sure that

## Focus Areas: Jobs, Education, and Regions

8:22

it's well organized and it's it's easy to use um and then the other side is

8:29

building the applications right um building web 3 apps so for this

8:34

hackathon we're going to focus on the first half so this is kind of the first big step right um organizing some

8:41

initial knowledge um that uh is using this gc20 primitive it's composable it's

8:48

extensible it's all these things that we want web 3 to be um and then on the other side uh as a next step down the

8:55

road uh coming up soon uh we will be able to build incred inredible web 3

9:00

apps that are way sicker than any apps that people have seen before in web 3 uh and it's going to be enabled by these

9:06

New Primitives um so the hackathon is five weeks it starts on February 3rd it's

9:13

online you can join from anywhere and we've got 150,000 GRT up for grabs um in

9:21

bounties uh and uh let's see um I guess

9:27

I'll just jump in straight into uh some of the uh areas that we want to focus on so you know our goal is to organize you

9:35

know the world's public knowledge and information um you know uh there are

9:40

commonalities between that mission and Google's mission right theirs is was also you know to to organize and make

9:46

Universal useful all the world's you know knowledge and information so you know people call called the graph the

9:51

Google a blockchain um but we need to get the real world data and knowledge on

9:57

chain on web 3 right and so uh we think a fun way to do this is to to bring in

10:04

some Focus areas so that people can collaborate and work together on a few kind of focus areas and and uh and we

10:11

think that'll be a really fun way to do this you can learn from each other and we can build something that's really useful in a few areas um and and we want

10:19

web 3 to move Beyond just kind of speculation beyond the the casinos um

10:24

you know uh and and so you know web 3 really is going to uh you know change

10:31

the whole economy right we we we have you know there's we have an opportunity to have you know uh a golden era right

10:38

now right a new Golden Age The Roaring 20s um and uh and web 3 is going to be a big

10:46

part of that so we need to get out into the real world so three of the areas we want to focus on are education jobs and

10:54

regions and um and let's start uh for example

11:00

with uh with jobs so um I want to

11:07

show um some brief examples so uh you may

11:13

have seen that we've launched geog Genesis it for Early Access um we're

11:19

we're going to be opening up opening this up more and more you know over the coming days and weeks um but uh we're

## The Role of AI in Knowledge Graphs

11:27

already starting to organize knowledge for uh uh a few different Industries

11:32

focusing on crypto to start um now this goo is just one application right um on

11:41

top of knowledge graphs you could build any kind of application right so so this is just you know a way to kind of see

11:48

knowledge and information in one way and and to contribute to it in one way um you could think of this almost like a

11:54

maybe like a a CMS or something right if you got your like WordPress and you've got a place you can go in and you can see all your stuff and then if you want

12:01

to have a custom website or something like that to your storefront you can right so um so here for example for the

12:08

crypto industry we'd want to see things like news you know maybe upcoming

12:14

events um you know projects that are in the crypto space um people who's working

12:20

in this industry uh and jobs and with jobs you'd want to see things like you know what are the different roles you

12:27

know maybe you know there's software engineering uh what are the different skills maybe solidity is super In Demand right maybe

12:33

rust is super in demand or or other things like marketing um so for every

12:38

industry you want to kind of organize these sorts of things um for the people that are working in that industry um and

12:46

uh and people who want to break into the industry um and uh and so these are just

12:52

kind of a few examples um now this is an older version of geog Genesis this is

12:58

what we were uh using before we launched um the uh

13:05

the new version that's based on GRC 20 uh we still have a lot of content here that we want to migrate over uh but uh

13:12

for now it's here uh and um just to show a few examples of a few different kind

13:17

of Industries um now uh people might have different industries that they're interested in and that's really great

13:24

and this is where we can kind of divide and conquer and divvy things up um personally I think agriculture is uh a

13:32

really interesting industry I think we want to see really big changes you know in places like the US where you know

13:39

they're using a lot of chemicals and unsustainable practices you know sometimes you know poisoning our food um

13:46

and you know I would love to see a shift you know towards more sustainable and uh

13:51

healthier uh practices for for agriculture so you can imagine that's an industry and you know at the same time

13:57

there's realities of that industry they you know they need to produce you know fruits vegetables and Grains and

14:03

livestock and all of these things um and the economics might be difficult you know there's lots of knowledge that's

14:10

required to do that job well um and so this is just an example of how to kind of you know organize an industry around

14:17

goals and try to see even you know from a top level like you know what are the areas of the economy that we'd love to

14:23

see transformed uh and maybe web 3 can help uh if we look at areas like social

14:29

work uh this is related to some of the work that we've done but here we've done I think a a better job it's still just a

## Hackathon Structure and Goals

14:34

beginning you know we have the kind of the goals but we also have uh here like different roles and skills so you could

14:43

imagine that if you're doing something like a you know let's say like a web 3 LinkedIn you know one of the first

14:49

things you do right is you create your resume and you're adding your skills and so what you want is a sort of drop down

14:56

of like here are the different roles here are the different skills and you want you want it all to be

15:02

interconnected right so that if I'm looking for a job and the job is you

15:07

know to be a software engineer or maybe it's a specific type of cryptographer or something that I could learn about that

15:13

role see you know which other uh companies are hiring for that same role

15:19

um and and maybe I can like learn about uh you know how How would how would I be

15:25

able to uh to to uh apply for something like that like what courses could I take

15:30

or what could I learn um and that takes us to the second area right which is

15:37

education um you know it's especially in the US you know um you know I think uh a

15:45

lot of people are seeing that the university system and even you know um you know grade schools you know that

15:51

system it's it's it's pretty broken and uh you know higher education Higher

15:57

Learning is is is really valuable but you know how how how do we organize the

16:03

accreditation how do we make it more accessible to people how do we make sure that you know these things aren't

16:09

getting captured um and and stop evolving right A lot of the stuff has

16:15

become really politicized and so you know I think web 3 uh can really uh play a big role in

16:23

helping to you know revolutionize education making it more accessible higher quality

16:29

um and uh and and all you know so much of that is knowledge you know um and

16:36

so to start you know we could look at what are the different you know academic

16:42

fields and um and for each of the academic Fields like what are the different courses what are the different

16:49

lessons what are the different topics so and and we could see you know different

16:54

degrees uh things that you know Pathways that people can learn accreditation things and and then we

17:01

could tie that to the jobs we've got some examples of you know maybe for

17:06

example like cryptography you know it's also related to um you know crypto and

17:13

maybe you could actually learn cryptography on something like this um so you could start just by like C

17:18

categorizing and kind of organizing these top level topics lessons courses this kind of stuff if you know get to

17:26

more and more content uh but just the organization of it and the mapping it um

17:32

is uh is really powerful um uh and then finally uh

## Engaging with the Community and Q&A

17:39

regions so uh you know we live in the real world and uh and we have you know

17:47

uh existing countries and states and cities and we want all of that to be part of the knowledge graph right this

17:53

is really going to empower Next Generation applications so you know with the Knowledge Graph we want to have it

18:00

so that you know people can search for things and there's already an entity for

18:06

that thing right so um let's say that I was building an app for events right I

18:11

want to build the next Meetup and somebody's creating an event and it's going to be in you know the city of San

18:19

Francisco uh what do we know about the city of San Francisco is it something that you can point to and and then you

18:25

could kind of query to for example show all of the events that are happening in San Francisco that would be really great

18:32

um but you know if every application is using a different ID for the city of San

18:38

Francisco then how are we going to do that right these guys are using this ID those guys are using that ID and then

18:43

there's no way for me to aggregate that really well together and so that's where the composability comes in and that's

18:49

why we really want to have this like Global Knowledge Graph and so I would want to for example search for San

18:55

Francisco and see oh here's a city right the city of San

19:00

Francisco and I could integrate that into my app right so you know you could have autocomplete for everything uh and

19:09

we'd want to have information about like cities so for example here right the city of San Francisco maybe you'd want

19:14

to have like you know local news and events and places right at all the local

19:19

businesses you know and we can do things like arts and culture you know and and help Revitalize cities and help people

19:26

find interesting things to do um so uh these are all examples of the kinds of

19:32

things that we could do at a local level right and we we could do this at a local level right for cities um but also we

19:38

can organize information that's relevant to like countries or states or at different um you know kind of Scopes so

19:47

this is just an example right of what a city page could look like with Upcoming Events maybe trending restaurants

19:53

neighborhoods and all of this stuff would then be part of the knowledge graph so you know the more knowledge

19:59

that we add the better it's organized right and now using this kind of composable

20:04

ontology um where you know you can have the ReUse and you can have the composability but you can also customize

20:11

things right this is really what web 3 is all about um you know we want to make it easier and easier to build the next

20:18

great app um and when we have these composable Primitives that's exactly

20:25

what we can do um so so this is some example of some of the content that we

20:30

could look to um to organize uh for those three different areas right the jobs the education and

20:38

the regions and uh next I just want to talk a little bit about um you know some of

20:45

the tools that you could be using and uh um and and you know some skills that you

20:51

could learn along the way so we've talked a little bit about knowledge graphs and um you you know right now uh

21:00

AI is super hot right hopefully you've had a chance to play around with AI um

21:05

it's really incredible what we can do with these tools um so AI is really going to intersect with knowledge graphs

21:11

in two main ways one is it's going to make it way faster and easier to ingest

21:18

knowledge and put it into the knowledge graph right AI can automate a lot of stuff that before would have taken us a

21:25

lot of time so it's really a superpower in that way you can leverage those superpowers to do super things um the

21:32

other way that uh the two really intersect is in how you consume the

21:38

knowledge from the knowledge graph are these llms are super powerful and you

21:43

you want to be able to uh have a great easy interface for you know uh

21:48

retrieving knowledge with natural language and so uh there's really you

21:54

know two different ways right now that people kind of structure this stuff for llm so uh you have these embeddings and

22:00

vectors right which deals with the textural representation of the

22:05

information and uh some of the things that llms uh you know some of those components do really well is you know if

22:12

you have these embeddings um you can do kind of similarity searches right and and those things are are really great um

22:19

you know if you have some question it it can find like relevant information based

22:26

on similarity of of the word words um and that's really powerful uh but what

22:32

that doesn't do is actually encode you know real meaning right it's this kind

22:38

of probabilistic thing but it doesn't actually know what is correct whereas with knowledge graphs

22:46

you're able to structure things you know really accurately the relationships between different things and you're able

22:53

to keep that up to date right so we've all had the experience of you're using an llm and gives you an answer that is

22:59

suboptimal right maybe it's maybe it's in you know it maybe it was true you

23:05

know a year ago but it's no longer accurate or you know there's all kinds of ways in which the in information that

23:12

it gives you might might be wrong and then it's it's hard to kind of correct it and it's hard to know okay you know

23:18

what exactly did you base that answer on now some of these AI tools have gotten better because they can actually link to

23:25

the primary sources but again it's not not very precise and so in an Ideal World we

23:32

would have entities for everything everything would be structured correctly the entities themselves and the

23:38

relationships between them and then when you ask an Lama

23:44

question what it does is a graph query against the knowledge graph right so you

23:50

ask a question right it does a graph query against the knowledge graph gives

23:55

you back the relevant information and then the llm can take that and generate the answer that's based on the correct

24:01

accurate rep you know knowledge um and so that is extremely powerful um and uh

24:10

and so that's kind of some of the stuff that we'll be able to do you know when we structure more of this knowledge and

24:16

information into a Knowledge Graph um for this

24:22

hackathon um you know using AI to to ingest a lot you know this knowledge and

24:30

information it's going to be a real superpower and you'll be able to play with different models and uh and and

24:36

build up your stack of tools for leveraging AI uh to to do cool things um

24:45

so uh that's some of the content I wanted to cover so I'd be super interested in just kind of opening this

24:51

up and kind of having a conversation um about uh you know the hackathon about

24:57

knowled graphs about what we want to accomplish really open to any kind of questions and conversations at this

25:03

point awesome awesome and so yeah we do have some good questions in the chat

25:10

we'll go right down the list here we go any idea who will be the judges if yes

25:18

can you share um I don't know that I want to share the specific people per se but um It's a combination of folks at

25:25

the graph foundation and at Gio all right next question can you give a couple examples of what you would like

25:31

to see for this hackathon proposal yeah now keep in mind for so okay the

25:37

submission is meant to be pretty simple so um so there's a link here right to

25:42

apply uh we just have a few questions and um and honestly I mean you you

25:48

really just want to demonstrate that you're a real person you know and that uh this is an area that you're

25:53

interested in um but uh you know don't be too worried about the application as

26:00

long as uh those things apply uh now we're going to spend the

26:05

first week of the hackathon basically um you know coming up with

26:12

ideas and focus areas and uh when it comes to this type of a hackathon

26:17

there's kind of an interesting balance that we want to strike it's interesting because we're actually going to create

26:22

something that is is useful right A lot of times with hackathons uh you you do a project and

26:28

then it's kind of throw away right our goal is that you know you can hack hack

26:34

around and you can learn and experiment and play and and do some cool things but the thing that you build is actually

26:40

going to be useful right maybe you could enable like you know 10 amazing applications based on this so so that's

26:46

really cool um and uh you know so to do that essentially what we want to do is

26:54

balance like what kind of knowledge and information would be most use useful and

27:00

we have some ideas about that and you know maybe you also have Amazing Ideas maybe your ideas are better than ours so

27:06

you know we want to you know try to look at okay what would be the most useful knowledge and information that would

27:11

enable interesting applications you know in these areas um and then we want to match that against really your interests

27:18

right what what things excite you you know you'll you'll always do better work if uh if you're naturally passionate or

27:24

interested in a specific you know in the thing that you're doing so that's what we got to figure out is what does that

27:30

match and in an ideal world uh we we minimize duplication you know it would

27:36

be unfortunate if you know two different people or teams you know spent four weeks they came back and they had the

27:43

exact same knowledge that they were importing right um that would be duplicated uh and and potentially wasted

27:49

work so in an Ideal World what we do is we kind of figure that out and then we

27:55

kind of assign areas of ownership that based on on what would be useful and based on what you're interested in and

28:01

then you kind of know okay if I knock this out of the park and I spend a bunch of time and I do a good job with this

28:06

you know it's it's it's not going to be duplicated it's going to really become part of this Global graph um that could

28:13

enable a bunch of interesting applications yeah very cool and uh I

28:18

will second that notion about haathon teams build for yes the hackathon and

28:25

then also likely if you're thinking big and you're thinking in terms of what

28:32

could be useful in an interesting project to you long term not only are you more likely to win the hackathon but

28:39

also uh carrying the project on and forward and really internalizing a

28:45

different way of thinking is the long-term benefit so yeah for sure go

28:50

for the short-term prize that's great and also think about something that you can carry with you and that that's

28:57

that's second that you need was a good concept there see a little bit of a longer

29:03

question here what is your take on the GRC 20/ geog Genesis tackling the parent

29:10

child cousin structure of l1's versus l2s versus cross chain perah subhub

29:16

chains living in l2s and l3s Etc I would love to share my take maybe as a

29:21

hackathon proposal but not sure it would even a h so that's super interesting

29:29

um would love to hear your take um I do wonder if what you're thinking of

29:35

building might be different than this goal of organizing knowledge uh for this

29:40

hackathon um so maybe that becomes an interesting one for a a different hackathon that we do but for sure the

29:46

infrastructure stuff is interesting so um yeah I would love to chat about that I mean right now geog Genesis is

29:53

launched on uh one chain right that's it's it's a it's technically a layer

29:59

three chain on top of arbitrum and uh and that's just kind of the initial chain one of the reason you

30:05

know it's it's geog Genesis this is just kind of the first step but ultimately knowledge is going to live on lots of

30:11

different chains right no question about that and so uh you know all of this

30:17

infrastructure you know should be open and composable um now the considerations

30:23

with knowledge is a little bit different than the considerations with value and it's interesting to to consider the

30:28

blockchain engineering implications of that right um when you're talking about value and money um your primary concern

30:36

is double spend right and what you don't want is you know somebody to move a million dollars onto a chain and then

30:45

that money gets stuck or it gets stolen by The Operators and then and then you can't get it back right so so the that's

30:52

the type of security you're thinking about for money now for knowledge

## The Nature of Knowledge and Data Availability

30:58

knowled doesn't exactly have that property right it doesn't necessarily like get stuck right it's not like ah my knowledge is over there and now

31:04

I can't use it right uh and so you do want the data to be available right you want data availability you want you know

31:11

good Storage Solutions and accessibility you want it to be index so you can query it but but there is value in having

31:19

consensus We Believe on knowledge to kind of you know uh for the same reason the databases are acid compliant right

31:27

and asset compliant database has like automic and it has like

31:32

consistency um and for many Information Systems you want that consistency you don't want it so that you know things

31:39

are in a inconsistent State and um and so so these are kind of interesting

31:46

questions so ultimately you know uh the question of how do you create a global graph where there's uh you know

31:52

consensus on the state of the knowledge graph even as you know people are

31:58

applications that are living on different chains and all this kind of stuff that's super interesting and uh

32:03

yeah we should be having more you know uh discussions about those types of topics yeah and I I might I see a few of

32:11

questions on there but this is a followup for myself to you you need and I know this is geog Genesis I know this

32:17

is gc20 that literally just a few weeks ago was proposed publicly and now is

32:25

taking more stape and having testing and I mean this is this is a big push what

32:30

would you say to any other developers or BD or marketing or anyone tuning in

32:37

right now who's part of another protocol who is just starting to hear about GRC 20 and what it might mean for them uh in

32:44

the future yeah so at this stage you know when things are early you know it's it's

32:52

probably best to be part of like you know the the core crew of developers that are building it develop you know it

32:58

developing it because that's how you're going to learn the most you know we want to shape this as a community so you you

33:04

want to get involved right so things like this hackathon is a great way to get close to that conversation now uh

33:09

what's it going to mean as we as this stuff grows right and so you know I think this hackathon is going to be a

33:16

really big piece of demonstrating the next level of growth and then we'll have

33:21

a lot more that we can see we'll have a lot more developers that understand how to use these tools and they can go off

33:27

and they can teach other people so uh you know at that stage maybe uh you know

33:33

we'll be ready for people to use us in different types of applications you know keeping in mind also um you know right

33:39

now we're we're kind of organizing the knowledge on on Geo here we're going to be using tools outside of Goo right

33:46

that's why you know it's a hackathon so developers will be writing scripts and tools and different things to generate the

33:51

knowledge uh but we haven't yet released the tools to build custom applications

33:57

um so that's going to be coming up and that is also very exciting um and so you

34:03

know the risk with the sort of thing is you know what we want to do is create a stable Foundation right we want to

## Creating a Stable Foundation for Applications

34:10

enable you to build applications that will actually live forever right where

34:15

you could build your piece of like here's a really cool flow and you can release that and you

34:23

know if only a thousand people love that user interface they can use it and they

34:29

can know that they'll be able to continue to use it forever right and they're not taking this risk on you and

34:35

that's what we 3 you know is really about because you know it makes it so it's easier for people to build stuff

34:42

and it's easier for people to use stuff right because it's not this thing where they're burnt out of you know if I use

34:47

this thing and then the app developer goes away then all of the time that I spent investing in this thing is gone

34:53

right and and and that'll make it easier for the developers because users will be more willing to try stuff right so um so

35:01

so so if if the promise is you know we're going to give you a a a stable

35:06

Foundation to build really cool apps uh there's obviously tension with

35:11

that in the very earliest days because by definition at the very earliest days you know we we're at the bleeding edge

35:17

but we but but you know so gc20 is really meant to be one of those

35:22

core foundational pieces the next layer for how you build your application that's it's going to come out super soon

35:29

and so the main thing at this point is just to learn you know learn the concepts learn about ontologies about

35:36

types about you know properties relations you know why we Define things

35:42

kind of in this way um and then really the idea is going to be that you know

35:47

people kind of rebuild their apps using composable Primitives uh and and maybe

35:53

it doesn't take a ton maybe it's just some slight tweaks but uh but but you know really it comes down to how do you

36:00

structure the information for your app right and what's the what and and how do you generate metadata or how do you how

36:06

do you generate knowledge or information for your app right like if if we look at like you know web 3 apps today I mean I

36:13

don't see a big proliferation of non-financial applications right and I think part of that is actually that this

36:18

piece was missing you know so you could look at something like nfts and say that that was maybe the first breakout

36:26

application of web 3 you know you had kind of the tokens and the iOS and then

36:31

nfts were the first thing even though they were mostly Financial but they also had this component that was

36:37

non-financial right which is jpegs and um and and and how did we

36:44

store those beautiful jpegs right we had Json that we would put sometimes on ipfs

36:51

sometimes on centralized servers right and uh and then we would anchor that on

36:56

chain um and you know when you have that

## Challenges in Structuring Non-Financial Applications

37:01

metadata is that Json that is not composable right and so

37:08

the nft stuff they never really became super composable now it's the same thing with Dows so Dows are an application

37:14

that are on chain and that's super interesting right you're like oh we can have proposals we can vote on things but

37:19

how do we structure the information for dowas right you have these proposals what are those proposals they're Json

37:26

objects right uh they have these are the fields and you know what are we using as

37:32

IDs in those fields what happens if the structure of a proposal changes and we want you know it's it's it's too rigid

37:41

and so because you know so so that is I think how most people have thought about

37:46

building things in web 3 and then and now we have these things like foraster and there's interesting experimentation

37:52

happening in foraster but I I think they kind of have like the same problem right which is is it's too rigid of a

37:59

structure right now we're trying to Define this protocol as like a social you know thing you know and and

38:07

people get excited about web 3 social but I don't think you can really design a protocol to be application

38:14

specific in that way you know it's inherently rigid it's like okay so now the protocol defines what are all of the

38:19

social actions that we can perform or the protocol specifies these these are all of the types of things right okay

38:25

there's posts and and video whatever but but then that becomes rigid and so what

38:31

really need is a generalized way of defining types and defining properties and defining relationships between

38:38

things and making that things that can evolve that that applications can extend and again that's where the knowledge

38:44

graphs come come come back so ultimately I do think people will need to you know

38:49

build their applications using the correct composable Primitives and the ones that do will be part of this Global

## The Need for Generalized Protocols

38:56

web that's open verifiable and composable and as we grow this thing as

39:01

there's more useful knowledge and information and as there's better and better user interfaces that are all composable you know people are going to

39:08

want to use this stuff and and and that's kind of the bet is that like this thing is going to be freaking amazing um

39:14

and we just got to kind of you know Kickstart this process yeah I mean just to have I mean just to have a win of

## Standardization of IDs Across Databases

39:21

having cross database standardization of an ID that would be just start with

39:28

if we could just if if if I'm all on board just to have uh more

39:34

standardization of IDs and and and everything that comes from uh from that

39:41

just in that fundamental primitive I'm all for any type of little bit of agreeance cross data sharing uh cross

39:49

databases and there's so many different types of databases there so many different ways to store data and therein is the centralization aspect of it and

39:56

therein is the you know kind of like so many different ways of store if if there's an AG if there's a way that we

40:02

could have more more agreeance on this that would be very very nice yeah so that's actually a very interesting point

40:07

you just made there um and I'd love to uh you know double tap on that so like

40:13

gc20 is really about how the knowledge is stored at rest fundamentally now from

40:19

there um you could index that in different databases and to your point you know there's different types of

40:25

databases out there some people love postgress right um some people want to play around with uh graph databases you

40:33

know things like neo4j um you know uh maybe it all just goes into a vector database or elastic

40:39

search or you know so you you that becomes part of the next stage in the

40:46

pipeline and in the stack right where you have your your knowledge at

40:52

rest and then you can ingest that into different types of databases or write in graph Parlin so those would be data

40:58

services so you could have different data services um uh so that you can use

41:04

you know the plethora of different databases that are may be optimized for different read access patterns I'm seeing some uh more questions in here uh

## Populating Knowledge with Web2 Data

41:12

we are looking to populate okay uh we are looking to populate this knowledge with existing

41:18

and accessible uh uh from data from web 2 if so how much this talking about I

41:25

assume the gc20 hackathon this question specifically are we looking to populate this knowledge with existing and

41:30

accessible data from web 2 and if so how much of our Focus will uh be on verifiability on that data yes that's

41:38

exactly right you could think about this a little bit like as like a a vampire

41:44

attack on web to so cool let's do it right there's so

41:50

much knowledge and information that's on the open web and uh and in a lot of ways you know

41:56

it's similar to what the teams have done right if you think about all of the AI models how did they get trained yeah

42:04

they got straight straight right they they vacuumed it up and uh

## Governance and Verifiability in Knowledge Systems

42:11

and then and then they built something you know useful and so you know we want to do the same thing now our bet is you

42:18

know that kind of with token incentives you know we can uh make that fun and profitable so

42:25

um uh yeah yes as far as the verifiability I mean essentially where

42:30

this comes down to is uh well governance now I have a post we actually need to

42:36

fix so I'm going to uh embarrassingly admit that we had an issue with our uh bullets and we're fixing that right now

42:44

okay on graph Builders we're all Builders here so little errors here and there are part of the of the workflow

42:50

right guys yeah yeah so okay so so I shared this post knowledge grafts web3

42:56

please read this if you after that there was the next post which was introducing jc20 and then over the break uh kind of

43:03

in December right before the break I published governing public knowledge uh

43:09

now I need to fix the bullets because I'm missing the bullets but other than that this is a very seminal post and I

43:14

recommend everybody read it um maybe we'll tell you when hope later I'm Shing in the chat right now yeah uh oh let's

43:21

let's repost it later today after we fix the bullets but okay so basically so okay let's the question

43:29

is how do we design a system that converges toward truth um and we want that truth to be

## Designing Systems for Truth and Consensus

43:36

represented as a Knowledge Graph recognizing that any representation of knowledge is an imperfect approximation

43:43

of the truth right nobody can claim that they know the what the truth is but we can still try our best to represent it

43:50

and we can create a system that improves over time um and we want the system to

43:55

be open so we we have things like these personal spaces that anybody can publish anyone can create and and publish to and

44:02

then we have public spaces and the public spaces have governance and and the point of this governance is to allow

44:10

larger and larger groups of people to get to consensus now it's a super interesting idea here um and you get

44:18

into really interesting philosophical conversations and you know would love to have these conversations with more of

44:23

the community so I think it's super important and this really just gets to the heart of the structure of society

44:29

and I think if if you dive into this you get smack dab into like the biggest problems facing civilization today and

44:36

and and how actually the tools that we're building here can really be the solution to the biggest problems in the

44:42

world um and uh and so you know so much of it is is how do you know what what

44:48

what information to trust right and and how do we get large groups of people to agree and to work together and so um the

44:56

public spaces a way of doing that now um the idea with these spaces is that

45:03

um that each space should be able to Define its own governance process and um and it's going to be

45:11

different for different spaces now at the beginning we have a default governance uh that we've launched with

45:18

um we think it's a great place to start but it's going to be very imperfect and and and hopefully over time people will

45:26

experiment with you know even more interesting different governance um you know systems and uh and we can kind of

45:33

get at that problem uh so I'll describe the governance that we have right now just briefly is you know any public

## Quality Control in Open Knowledge Spaces

45:41

space like this you'll see has uh editors and members now I just created this so I'm the only one here but if we

45:46

go to like the crypto space we'll see that this one has three

45:52

editors and 16 members right and the members can basically propose changes

45:57

it's really easy to become a member you just request to join and you only need one Editor to approve your request in

46:03

order to become a member and then the members can propose changes to anything so so you can edit um you know you go

46:11

into edit mode you can propose changes and then when you publish your changes it goes to a vote of the editors so the

46:18

editors really meant to be more of the the experts and then the members is anyone who you know is basically you

46:24

know aligned with the values of the space space and and and kind of agrees to the goals and the policies and things

46:31

uh and essentially you'd participate in a space if you generally trust the editors and you think that they're good

46:38

and if you don't think that they're good then you know you can create your own space um so that's kind of uh the idea

46:44

there so as far as the verification what I would say is um yeah do your best to

46:50

get accurate knowledge and information um if it's not accurate uh you know

46:55

that's that's all going to be part of the judging process we're going to do our best to evaluate we might not be perfect uh but we we all want to do the

47:03

best job we can to be as accurate as we can um over time we can work on you know

47:08

interesting systems for you know like every space basically will have to experiment on their own for like what's

47:15

your verification process how do you make sure that you have good quality information and essentially it's the job

47:20

of the editors to ensure quality of the knowledge in their

47:25

space yeah I feel the um openness and collaboration quality control Trifecta

47:33

is uh one that is never will never be saw and the best way to do it is

47:38

transparently and openly and just try to have the people participating and having

47:46

quality information and and always evolving and always changing I feel like the the gc20 and then also these spaces

47:55

allow for that type of Evolution week to week to to year to year as as people changes as you know that changes so very

48:02

cool uh let's see got uh question here specific to uh scrap it uh when I look

48:09

around I usually build a quick scrape that goes across five to 50 job platforms curious about how geog Genesis

48:15

will take care of it being aggregator of all web 2 jobs just being indexer of all web 2 and web three sites actually list

48:22

them all and act uh an act and another platform to look at it's it's a it's a

48:27

schema thing for sure yeah totally yeah amazing and uh that sounds like exactly

48:34

the kind of stuff we want to be doing here so all of the above agree with everything that you said I think we want

## Defining Ontologies for Job Data

48:39

to start by defining uh you know the best ontologies that we can and that's

48:44

part of what we're going to be doing the first week right during next week of the hackathon um so if we're look at

48:50

something like jobs we want to agree on standardized types and relations to say

48:55

okay this is a job opening right and that'll you know reference a role you know it'll reference a project that's

49:03

hiring um you know what are the fields that we want to capture for the job openings and ideally that's mostly

49:10

standardized now again part of the benefit of the knowledge graphs is other applications can customize it so if they

49:16

want to reuse all of those fields that are kind of standardized but then for their specific application right it's

49:22

specifically for you know uh you know hiring do doctors and there's a different set of questions that they

49:28

need for hiring doctors they can add those additional fields and they can customize it but it's all still

49:33

interoperable and so um so that's kind of step one and then you're exactly right the web scraping is going to be

49:40

huge and you know we do want to essentially scrape all of the existing data that we can and I do think we see

49:46

like then you know the knowledge gra becoming kind of you know the agregation layer right so ideally you know now we

49:54

don't really want duplicates right you could have duplicates in the knowledge graph but it's not really valuable so we

50:00

could call that less well organized right if there's duplicates and so what you'd want is maybe they exist but the

50:07

stuff that people use should be better aggregated better organized so you'd remove the duplicates there and that's

50:13

ideally what people would actually be using as their source of truth right if if someone's building an application and

50:18

they want a query for all the job openings right they want that to be like a well organized no duplicate you know

50:24

standardized kind of list so that where we want to get to is that aggregation quality aggregation uh where you know

50:32

part of the value that we provide is that everything is better interconnected right so you know it's

50:38

not these one-offs a lot of times in these platforms right they you just use a text field for the location right they

50:43

just use a text field for you know the role or whatever and it's much better if

50:49

I could actually say hey like how many software engineer job openings are there

50:55

in the crypto space right that have been open for more than you know 3 months and you know what's the average salary or

51:01

like whatever it is that you might care to to get like you know the more interconnected everything is the better

51:09

applications we be able to build the more you know insights people will be able to derive the smarter the llms will

51:15

get you know all of the above so uh so that's the goal and then from there people will be able to build custom applications right that'll be kind of

51:22

The Next Step so you know is Gio going to be the best app app for you know job

## The Role of Aggregation in Knowledge Graphs

51:28

hunting and finding a job probably not um it will be a place where people who

51:34

are working on organizing the knowledge can really browse and dig in and understand every detail and have like

51:40

the full view so I think it'll be valuable for a large subset of people but what I would fully expect is you

51:48

know once we release the tools for building custom apps that people will build like super optimized amazing user

51:55

interfaces that is maybe tailored to you know better tailored to whatever markets

52:01

they want to serve cool cool I I I love the team of composability and and verifiability and having a I feel like

52:09

that's where web 3 is heading as a whole I mean I feel like there's this mind share across protocols across teams that

52:16

that has gotten to the point where how do we make more efficient this data sharing how do we

52:23

how do we do it better because there's so many different so many different ways it's happening it's like okay let's

52:29

let's they had this ballooning if you will and now it's it's settling and and

52:35

and I feel like this is part of that and that good problem you really do need the

52:40

right kind of standards and Primitives to enable that composability and I think

52:45

people do rightly feel that that hasn't existed yet and that's why we haven't quite had that yet and um and that

52:52

really is the core of web 3 and then once we have that you know I think uh

52:58

this idea then of being able to build even more like customized and specialized applications is going to be

## The Future of Custom Applications in Web3

53:05

really powerful right and I think that's a big part of the value of web 3 is you know imagine that every segment has like

53:13

a perfectly optimized application just for them right we can move away from these One siiz fits-all apps right if

53:20

you think about something like uh you know event Bri or Meetup those are one siiz fits all outs right it's the

53:27

rough I they're not bad but they're they're kind of rough at times they're kind of rough right it's the same Meetup app whether you know we're playing a

53:34

sports game or whether we're we're giving a JavaScript talk right and it's uh you know and it's the same app if

53:41

we're throwing a conference right well a conference is totally different right a conference maybe you've got multiple

53:46

stages over multiple days and there's all a whole other set of things um but you still want that interoperability I

53:53

still want to be able to you know show me all of the events you know in areas that I'm interested in next weekend and

54:00

let me browse and see like what's there and I I still want to be able to say okay like show me all of the talks that

54:07

vitalic has given in the last two years and show me you know what he announced

54:14

in those talks you know what were you know so all of this stuff it's all about

54:19

organizing knowledge and information making it composable but then you know that next step will be so powerful when

54:26

people can really build the custom apps and it's like whatever it is that you care about like the opportunities will

54:31

just be endless for better serving the markets that you care about right whatever it is you're passionate about

54:37

the people that you know you want to make happy you'll just have such better tools for giving them like super sick

54:43

apps yeah I can't wait yeah and I feel like I mean we were talking off screen just a few minutes before you were on

54:49

about how crypto and uh a lot of different web three concepts are

54:55

reaching a Tipping Point and here we are you know January 30th

55:00

2025 and what a time to be in this industry what a time to be pushing for

55:06

bleeding edge Tech what a time to be pushing for New Concepts this is an exciting time so yeah well you need I just want to

55:14

thank you for your time is there anything else that you'd want to share before we go ahead and release these

55:20

developers into the gc20 hackathon application yeah uh I'm just super

## Encouraging Developer Participation in GRC 20 Hackathon

55:26

excited to work with everybody so I'm going to be super Hands-On we've got a great team of people who are going to be

55:32

part of this I'll be able to learn from some great developers so it should be a lot of fun and uh the main thing I would

55:38

just say is apply today you know should only take 5 minutes it should be pretty quick and easy so you know the

55:44

applications close on Sunday but there's no reason to wait till then so apply today and we'll see you next week

55:51

awesome awesome hear that devs go ahead and apply today get out there and uh great having you out their chat uh was a

55:58

great conversation great questions out there and I'll see you guys next week as well and with that being said thank you

56:04

so much un for your time I really appreciate you pushing on this primitive pushing to get this out there pushing to

56:10

get this in front of devs and being transparent about this process that's a huge deal so thank you so much and uh

56:15

with that being said have a good rest of your Thursday everybody thanks

56:21

everyone stop the stream take care all right wait so